//
//  RGBAppApp.swift
//  RGBApp
//
//  Created by Alexander Zub on 24.06.2022.
//

import SwiftUI

@main
struct RGBAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
